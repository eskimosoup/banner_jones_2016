$(document).ready(function() {
  teamMembersSlick();
});

$(document).on('click', '.print-page', function() {
  window.print();
  return false;
})
;
