$(document).ready(function() {
  $('.testimonials-slick, .service-testimonials').slick({
    arrows: false,
    dots: true,
    autoplay: true,
    autoplaySpeed: 6000
  });
});
